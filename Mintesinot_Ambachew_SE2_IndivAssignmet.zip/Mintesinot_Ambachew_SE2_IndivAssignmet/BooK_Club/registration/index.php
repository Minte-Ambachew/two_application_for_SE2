<?php
  // Create database connection
  $db = mysqli_connect("localhost", "root", "", "image_upload");

  // Initialize message variable
  $msg = "";

  // If upload button is clicked ...
  if (isset($_POST['upload'])) {
  	// Get text
  	$book_text = mysqli_real_escape_string($db, $_POST['book_text']);

  	$sql = "INSERT INTO images (book_text) VALUES ('$book_text')";
  	// execute query
  	mysqli_query($db, $sql);
  }
  $result = mysqli_query($db, "SELECT * FROM images");
?>
<!DOCTYPE html>
<html>
<head>
<head>
  <title>Book Club</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/bootstrap.min.js"></script>
<style type="text/css">
   #content{
   	width: 70%;
   	margin: 20px auto;
   	border: 5px double #cbcbcb;
   }
  
</style>
</head>
<body>
<div id="content">
  <form method="POST" action="index.php" enctype="multipart/form-data">
  	<input type="hidden" name="size" value="1000000">
  	<div class="container">         
  <table class="table table-hover" id="tableid">
    <thead>
      <tr>
        <th>Cover Page</th>
        <th>Information</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td> <img class="img-responsive" src="images/images.jpg" alt="Chania"> </td>
        <td>Detail about the image</td>
    </tbody>
  </table>
</div>
  	<div>
				<!---the text area where the comment is entered -->
      <textarea 
      	id="text" 
      	cols="40" 
      	rows="4" 
      	name="book_text" 
      	placeholder="Say something about this Book..."></textarea>
  	</div>
  	<div>
  		<button type="submit" name="upload">POST</button>
  	</div>
      
  	<a href="login.php">Logout</a>
  	
    
  </form>
</div>
</body>
</html>