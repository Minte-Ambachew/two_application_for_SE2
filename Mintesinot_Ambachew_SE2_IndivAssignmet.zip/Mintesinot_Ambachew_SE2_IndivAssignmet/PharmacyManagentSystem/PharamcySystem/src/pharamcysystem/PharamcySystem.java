
package pharamcysystem;


public class PharamcySystem {

   private int id ;
   private String Name;
   private float price;
   private String drugtype;
   private String Amount_pack;

	public PharamcySystem (int Did,String Dname, float Dprice,String Dtype, String DAmount){
		this.id=Did;
		this.Name = Dname;
		this.price= Dprice;
		this.drugtype=Dtype;
		this.Amount_pack=DAmount;
	}
	public int getID(){
		return id;
	}
	public String getName(){
		return Name;
	}
	public float getPrice(){
		return price;
	} 
	public String getdrugtype(){
		return drugtype;
	}
        public String getAmount(){
            return Amount_pack;
        }
     
}
