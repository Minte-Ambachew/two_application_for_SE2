# Mintesinot_Ambachew_SE2_IndivAssignmet
NAME: Mintesinot Ambachew
ID NO: ATE/9671/08
DEPARTMENT: Software Engineering
                 Client-Serve Application 
Features of the Book Club Application
The main aim of the system is to initiate students to read books and get the chance to share ideas, reviews about some books posted in the system.
Registered members will also be able to,Join book conversation and Share ideas about specific books.
                MVC Application
Features of the Pharmacy Management System
The pharmacy management is built with java for GUI,controller part and MySql for the database,the application stores drug
entered into the pharmacy by using MySQL database system and shows the list of drugs found in table format,the user enters
the data by using the input format in the GUI.
